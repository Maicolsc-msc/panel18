<?php

if (basename($_SERVER["REQUEST_URI"]) === basename(__FILE__)) {
    exit('<h1>ERROR 404</h1>Contáctanos y envíanos los detalles.');
}

$buscasmtp = "SELECT * FROM smtp WHERE usuario_id='" . $_SESSION['usuarioID'] . "'";
$buscasmtp = $conn->prepare($buscasmtp);
$buscasmtp->execute();
$smtp = $buscasmtp->fetch();

$conta = $buscasmtp->rowCount();

?>
<script language="JavaScript">
    <!--
    function desabilitar() {
        with(document.form) {
            qtd_ssh.disabled = true;
        }
    }

    function habilitar() {
        with(document.form) {

            qtd_ssh.disabled = false;

        }
    }
    // 
    -->
</script>
<!-- Input with Icons start -->
<section id="input-with-icons">
    <div class="row match-height">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h1 class="card-title font-medium-2"><i class="fad fa-at text-info font-large-1"></i> Enviar email</h1>
                </div>
                <div class="card-content">
                    <form action="pages/email/enviandoemail.php" method="POST" role="form">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-sm-6 col-12">
                                    <div class="mb-1">
                                        <div class="mb-0">
                                            Tipo de servicio
                                        </div>
                                        <fieldset class="form-group position-relative">
                                            <select class="form-select" name="tipomodelo">
                                                <option value="1">Soporte Técnico</option>
                                                <option value="2">Entrega de Cuentas</option>
                                            </select>
                                        </fieldset>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-12">
                                    <div class="mb-1">
                                        <div class="mb-0">
                                            Tipo de cuenta
                                        </div>
                                        <fieldset class="form-group position-relative">
                                            <select class="form-select" name="tipoconta">
                                                <option value="1" selected=selected>Cuenta SSH</option>
                                                <option value="2">Acceso al panel</option>
                                            </select>
                                        </fieldset>
                                    </div>
                                </div>

                                <div class="col-sm-6 col-12">
                                    <div class="mb-1">
                                        <div class="mb-0">
                                            Asunto :
                                        </div>
                                        <fieldset class="form-group position-relative has-icon-left input-divider-left">
                                            <input type="text" class="form-control" id="assunto" name="assunto" value="Acesso de SSH Liberado" placeholder="Digite um Assunto EX: Compra de SSH ">
                                        </fieldset>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-12">
                                    <div class="mb-1">
                                        <div class="mb-0">
                                            Validez:
                                        </div>
                                        <fieldset class="form-group position-relative input-divider-right">
                                            <input type="text" class="form-control" id="validade" name="validade" value="30 Dias" placeholder="Validez 30">
                                        </fieldset>
                                    </div>
                                </div>

                                <div class="col-sm-6 col-12">
                                    <div class="mb-1">
                                        <div class="mb-0">
                                            Nombre de usuario:
                                        </div>
                                        <fieldset class="form-group position-relative has-icon-left input-divider-left">
                                            <input type="text" class="form-control" id="login" name="login" placeholder="Ingrese nombre de usuario">
                                        </fieldset>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-12">
                                    <div class="mb-1">
                                        <div class="mb-0">
                                            Contraseña:
                                        </div>
                                        <fieldset class="form-group position-relative input-divider-right">
                                            <input class="form-control" id="senha" name="senha" placeholder="Ingrese la contraseña">
                                        </fieldset>
                                    </div>
                                </div>

                                <div class="col-sm-6 col-12">
                                    <div class="mb-1">
                                        <div class="mb-0">
                                            Email :
                                        </div>
                                        <fieldset class="form-group position-relative has-icon-left input-divider-left">
                                            <input required="required" type="text" class="form-control" name="email" placeholder="Ingrese su correo electrónico y seleccione el servidor en el lateral">
                                        </fieldset>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-12">
                                    <div class="mb-1">
                                        <div class="mb-0">
                                            Servidor de email
                                        </div>
                                        <fieldset class="form-group position-relative input-divider-right">
                                            <select class="form-select" name="servidoremail" data-toggle="dropdown" aria-expanded="false">
                                                <option value="1" selected=selected>Yo decido</a></option>
                                                <option value="2">@Gmail.com</a></option>
                                                <option value="3">@Outlook.com</a></option>
                                                <option value="4">@Hotmail.com</a></option>
                                                <option value="5">@Yahoo.com.br</a></option>
                                            </select>
                                        </fieldset>
                                    </div>
                                </div>
                                <div class="col-12 text-center">
                                    <div class="mb-2">
                                        <div class="mb-0">
                                            Contenido del correo electrónico:
                                        </div>
                                        <fieldset class="form-group position-relative has-icon-left input-divider-left">
                                            <textarea class="form-control" name="msg" id="msg" rows="6" placeholder="Gracias por su preferencia, valoramos la calidad de su internet..">Gracias por su preferencia, valoramos la calidad de la conexión.</textarea>
                                        </fieldset>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-12 text-center">
                                    <button type="submit" class="btn btn-success">Enviar</button>
                                    <button type="button" class="btn btn-info"><a class="text-white" href="home.php?page=email/1etapasmtp">Configurar SMTP</a></button>
                                    <button type="reset" class="btn btn-danger">Limpiar</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Input with Icons end -->