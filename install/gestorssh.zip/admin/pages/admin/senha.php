<?php
require_once("../../../pages/system/seguranca.php");
require_once("../../../pages/system/config.php");
	protegePagina("admin");
		if(isset($_POST["senha"]) ){
			
		    $SQLUser = "select * from admin where id_administrador = '".$_SESSION['usuarioID']."'  ";
            $SQLUser = $conn->prepare($SQLUser);
            $SQLUser->execute();
			if(($SQLUser->rowCount()) > 0){
				
					        $SQLUser = "update admin set senha='".$_POST['senha']."' WHERE id_administrador = '".$_SESSION['usuarioID']."' ";
                            $SQLUser = $conn->prepare($SQLUser);
                            $SQLUser->execute();
							 echo '<script type="text/javascript">';
			                 echo 	'alert("Alterado con éxito!");';
			                 echo	'window.location="../../home.php?page=admin/dados";';
			                 echo '</script>';
			}else{
			    echo '<script type="text/javascript">';
			    echo 	'alert("No permitido!");';
			    echo	'window.location="../../home.php?page=admin/dados";';
			    echo '</script>';
			}
			
		}else{
			    echo '<script type="text/javascript">';
			    echo 	'alert("Llenar!");';
			    echo	'window.location="../../home.php?page=admin/dados";';
			    echo '</script>';
		}
	